"""
Constantes do jogo
"""

largura_tela = 1000
altura_tela = 500
velocidade_tela = 2
altura_chao = 465
QUANTIDADE_AUMENTO_VELOCIDADE = 1
MUDANCA_BACKGROUND = 1000